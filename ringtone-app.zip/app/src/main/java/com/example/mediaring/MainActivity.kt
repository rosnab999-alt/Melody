package com.example.mediaring

import android.Manifest
import android.app.Activity
import android.app.NotificationManager
import android.content.Intent
import android.content.pm.PackageManager
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.net.Uri
import android.os.Bundle
import android.provider.OpenableColumns
import android.provider.Settings
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Switch
import android.widget.TextView

class MainActivity : Activity() {

    private lateinit var status: TextView
    private lateinit var fileName: TextView
    private lateinit var volLabel: TextView
    private lateinit var testBtn: Button
    private lateinit var serviceBtn: Button
    private var testPlayer: MediaPlayer? = null

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun button(text: String, onClick: () -> Unit): Button {
        val b = Button(this)
        b.text = text
        b.setOnClickListener { onClick() }
        return b
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setPadding(dp(16), dp(24), dp(16), dp(24))

        val title = TextView(this)
        title.text = "Рингтон через медиа-канал"
        title.textSize = 22f
        root.addView(title)

        status = TextView(this)
        status.setPadding(0, dp(12), 0, dp(12))
        root.addView(status)

        root.addView(button("Выбрать мелодию") { pickFile() })

        fileName = TextView(this)
        fileName.setPadding(0, dp(8), 0, dp(8))
        root.addView(fileName)

        volLabel = TextView(this)
        root.addView(volLabel)

        val seek = SeekBar(this)
        seek.max = 100
        seek.progress = Prefs.volume(this)
        seek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                Prefs.setVolume(this@MainActivity, p)
                updateVolLabel()
                testPlayer?.setVolume(p / 100f, p / 100f)
            }

            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
        root.addView(seek)

        testBtn = button("Проверить звук") { toggleTest() }
        root.addView(testBtn)

        val mute = Switch(this)
        mute.text = "Глушить системный рингтон"
        mute.isChecked = Prefs.muteRinger(this)
        mute.setOnCheckedChangeListener { _, c -> Prefs.setMuteRinger(this, c) }
        mute.setPadding(0, dp(16), 0, dp(8))
        root.addView(mute)

        root.addView(button("Доступ к «Не беспокоить»") {
            startActivity(Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS))
        })
        root.addView(button("Настройки приложения (автозапуск, батарея)") {
            startActivity(
                Intent(
                    Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                    Uri.parse("package:$packageName")
                )
            )
        })

        serviceBtn = button("") { toggleService() }
        val lp = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        )
        lp.topMargin = dp(24)
        serviceBtn.layoutParams = lp
        root.addView(serviceBtn)

        val sv = ScrollView(this)
        sv.addView(root)
        setContentView(sv)
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    override fun onPause() {
        super.onPause()
        stopTest()
    }

    private fun updateVolLabel() {
        volLabel.text = "Громкость мелодии: ${Prefs.volume(this)}%"
    }

    private fun refresh() {
        val phone = checkSelfPermission(Manifest.permission.READ_PHONE_STATE) ==
                PackageManager.PERMISSION_GRANTED
        val dnd = getSystemService(NotificationManager::class.java).isNotificationPolicyAccessGranted
        status.text = "Разрешение «Телефон»: ${if (phone) "есть" else "нет"}\n" +
                "Доступ к «Не беспокоить»: ${if (dnd) "есть" else "нет"}\n" +
                "Служба: ${if (Prefs.enabled(this)) "включена" else "выключена"}"
        fileName.text = "Мелодия: " + (Prefs.uri(this)?.let { nameOf(it) } ?: "системная по умолчанию")
        updateVolLabel()
        serviceBtn.text = if (Prefs.enabled(this)) "Остановить службу" else "Запустить службу"
    }

    private fun nameOf(uri: Uri): String {
        try {
            contentResolver.query(uri, null, null, null, null)?.use {
                if (it.moveToFirst()) {
                    val i = it.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                    if (i >= 0) return it.getString(i)
                }
            }
        } catch (_: Exception) {
        }
        return uri.lastPathSegment ?: "файл"
    }

    private fun pickFile() {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT)
        i.addCategory(Intent.CATEGORY_OPENABLE)
        i.type = "audio/*"
        i.addFlags(
            Intent.FLAG_GRANT_READ_URI_PERMISSION or
                    Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION
        )
        startActivityForResult(i, 10)
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 10 && resultCode == RESULT_OK) {
            val uri = data?.data ?: return
            try {
                contentResolver.takePersistableUriPermission(
                    uri, Intent.FLAG_GRANT_READ_URI_PERMISSION
                )
            } catch (_: Exception) {
            }
            Prefs.setUri(this, uri)
            refresh()
        }
    }

    private fun toggleTest() {
        if (testPlayer != null) {
            stopTest()
            return
        }
        val v = Prefs.volume(this) / 100f
        val mp = MediaPlayer()
        try {
            mp.setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                    .build()
            )
            mp.setDataSource(this, Prefs.uri(this) ?: Settings.System.DEFAULT_RINGTONE_URI)
            mp.isLooping = true
            mp.setVolume(v, v)
            mp.setOnPreparedListener { it.start() }
            mp.prepareAsync()
            testPlayer = mp
            testBtn.text = "Остановить проверку"
        } catch (e: Exception) {
            mp.release()
            status.text = "Не удалось воспроизвести: ${e.message}"
        }
    }

    private fun stopTest() {
        testPlayer?.let {
            try {
                it.stop()
            } catch (_: Exception) {
            }
            it.release()
        }
        testPlayer = null
        if (::testBtn.isInitialized) testBtn.text = "Проверить звук"
    }

    private fun toggleService() {
        if (Prefs.enabled(this)) {
            stopService(Intent(this, RingService::class.java))
            Prefs.setEnabled(this, false)
            refresh()
            return
        }
        val need = ArrayList<String>()
        if (checkSelfPermission(Manifest.permission.READ_PHONE_STATE) != PackageManager.PERMISSION_GRANTED)
            need.add(Manifest.permission.READ_PHONE_STATE)
        if (checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED)
            need.add(Manifest.permission.POST_NOTIFICATIONS)
        if (need.isNotEmpty()) {
            requestPermissions(need.toTypedArray(), 1)
            return
        }
        startRing()
    }

    private fun startRing() {
        startForegroundService(Intent(this, RingService::class.java))
        Prefs.setEnabled(this, true)
        refresh()
    }

    override fun onRequestPermissionsResult(code: Int, perms: Array<out String>, res: IntArray) {
        super.onRequestPermissionsResult(code, perms, res)
        if (checkSelfPermission(Manifest.permission.READ_PHONE_STATE) == PackageManager.PERMISSION_GRANTED) {
            startRing()
        } else {
            refresh()
        }
    }
}
