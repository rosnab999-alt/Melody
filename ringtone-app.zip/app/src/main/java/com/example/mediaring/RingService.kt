package com.example.mediaring

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.media.AudioAttributes
import android.media.AudioFocusRequest
import android.media.AudioManager
import android.media.MediaPlayer
import android.os.IBinder
import android.provider.Settings
import android.telephony.TelephonyCallback
import android.telephony.TelephonyManager

class RingService : Service() {

    private var player: MediaPlayer? = null
    private var callback: CallCb? = null
    private var prevRinger = -1
    private var focusReq: AudioFocusRequest? = null

    private val attrs = AudioAttributes.Builder()
        .setUsage(AudioAttributes.USAGE_MEDIA)
        .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
        .build()

    private inner class CallCb : TelephonyCallback(), TelephonyCallback.CallStateListener {
        override fun onCallStateChanged(state: Int) {
            if (state == TelephonyManager.CALL_STATE_RINGING) onRinging() else onCallEnded()
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        try {
            startForeground(
                1, buildNotification(),
                ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK
            )
        } catch (e: Exception) {
            stopSelf()
            return START_NOT_STICKY
        }
        if (callback == null) {
            try {
                val tm = getSystemService(TelephonyManager::class.java)
                val cb = CallCb()
                tm.registerTelephonyCallback(mainExecutor, cb)
                callback = cb
            } catch (e: SecurityException) {
                stopSelf()
                return START_NOT_STICKY
            }
        }
        return START_STICKY
    }

    private fun buildNotification(): Notification {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel("svc", "Служба рингтона", NotificationManager.IMPORTANCE_LOW)
        )
        val pi = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE
        )
        return Notification.Builder(this, "svc")
            .setSmallIcon(android.R.drawable.stat_sys_phone_call)
            .setContentTitle("Медиа-рингтон активен")
            .setContentText("Мелодия звонка играет через медиа-канал")
            .setContentIntent(pi)
            .setOngoing(true)
            .build()
    }

    private fun onRinging() {
        val nm = getSystemService(NotificationManager::class.java)
        val am = getSystemService(AudioManager::class.java)
        if (Prefs.muteRinger(this) && nm.isNotificationPolicyAccessGranted) {
            if (prevRinger == -1) prevRinger = am.ringerMode
            try {
                am.ringerMode = AudioManager.RINGER_MODE_SILENT
            } catch (_: Exception) {
            }
        }
        startPlayer()
    }

    private fun onCallEnded() {
        stopPlayer()
        if (prevRinger != -1) {
            val am = getSystemService(AudioManager::class.java)
            try {
                am.ringerMode = prevRinger
            } catch (_: Exception) {
            }
            prevRinger = -1
        }
    }

    private fun startPlayer() {
        if (player != null) return
        val am = getSystemService(AudioManager::class.java)
        focusReq = AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN_TRANSIENT)
            .setAudioAttributes(attrs)
            .build()
        am.requestAudioFocus(focusReq!!)

        val vol = Prefs.volume(this) / 100f
        val mp = MediaPlayer()
        mp.setAudioAttributes(attrs)
        try {
            val chosen = Prefs.uri(this)
            if (chosen != null) {
                try {
                    mp.setDataSource(this, chosen)
                } catch (e: Exception) {
                    mp.reset()
                    mp.setAudioAttributes(attrs)
                    mp.setDataSource(this, Settings.System.DEFAULT_RINGTONE_URI)
                }
            } else {
                mp.setDataSource(this, Settings.System.DEFAULT_RINGTONE_URI)
            }
            mp.isLooping = true
            mp.setVolume(vol, vol)
            mp.setOnPreparedListener { it.start() }
            mp.prepareAsync()
            player = mp
        } catch (e: Exception) {
            mp.release()
        }
    }

    private fun stopPlayer() {
        player?.let {
            try {
                it.stop()
            } catch (_: Exception) {
            }
            it.release()
        }
        player = null
        focusReq?.let { getSystemService(AudioManager::class.java).abandonAudioFocusRequest(it) }
        focusReq = null
    }

    override fun onDestroy() {
        callback?.let {
            getSystemService(TelephonyManager::class.java).unregisterTelephonyCallback(it)
        }
        callback = null
        onCallEnded()
        super.onDestroy()
    }
}
