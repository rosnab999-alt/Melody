package com.example.mediaring

import android.content.Context
import android.net.Uri

object Prefs {
    private fun sp(c: Context) = c.getSharedPreferences("prefs", Context.MODE_PRIVATE)

    fun uri(c: Context): Uri? = sp(c).getString("uri", null)?.let { Uri.parse(it) }
    fun setUri(c: Context, u: Uri) = sp(c).edit().putString("uri", u.toString()).apply()

    fun volume(c: Context): Int = sp(c).getInt("volume", 100)
    fun setVolume(c: Context, v: Int) = sp(c).edit().putInt("volume", v).apply()

    fun muteRinger(c: Context): Boolean = sp(c).getBoolean("mute", true)
    fun setMuteRinger(c: Context, v: Boolean) = sp(c).edit().putBoolean("mute", v).apply()

    fun enabled(c: Context): Boolean = sp(c).getBoolean("enabled", false)
    fun setEnabled(c: Context, v: Boolean) = sp(c).edit().putBoolean("enabled", v).apply()
}
